/*
 * Ian Leuty
 * ileuty@pdx.edu
 * 2/16/2025
 * CS302 Winter 2025
 * Program #3
 *
 ********************************************************************
 *
 *
 * main
 *
 *********************************************************************
 */

#include "application.h"
using namespace std;

int main(void)
{
    srand(time(0));
    Menu the_menu;


    the_menu.prompt();

    return 0;
}

